const mongoose = require("mongoose");

mongoose.connect(
  `mongodb+srv://prabeshkhatrichhetri:kJZrqMdhWsgUrHOC@cluster0.hmrzovx.mongodb.net/?retryWrites=true&w=majority`,
  { useNewUrlParser: true }
);

const connection = mongoose.connection;

module.exports = connection;  